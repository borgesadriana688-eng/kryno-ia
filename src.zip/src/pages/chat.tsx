import React, { useState, useEffect, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListConversations,
  useCreateConversation,
  useGetConversation,
  useDeleteConversation,
  getGetConversationQueryKey,
  getListConversationsQueryKey
} from "@workspace/api-client-react";
import { Plus, MessageSquare, Trash2, Send, Zap, ChevronLeft, Menu, LogOut, ImagePlus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useClerk, useUser } from "@clerk/react";
import ReactMarkdown from "react-markdown";

const WELCOME_MESSAGE = "Olá! Sou a Kryno IA, sua assistente inteligente criada por Brayan Rafael. Como posso te ajudar hoje?";
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function ThinkingIndicator() {
  return (
    <div className="flex w-full justify-start">
      <div className="max-w-[85%] rounded-xl px-4 py-3 bg-primary/5 border border-primary/20">
        <div className="flex items-center gap-2 mb-2">
          <div className="h-5 w-5 rounded-md bg-primary/20 flex items-center justify-center border border-primary/40">
            <Zap className="h-3 w-3 text-primary" />
          </div>
          <span className="font-mono text-[10px] text-primary tracking-widest uppercase">Kryno</span>
        </div>
        <div className="flex items-center gap-1.5 py-1">
          <span className="h-2 w-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "0ms" }} />
          <span className="h-2 w-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "150ms" }} />
          <span className="h-2 w-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "300ms" }} />
        </div>
      </div>
    </div>
  );
}

export default function ChatPage() {
  const [activeConversationId, setActiveConversationId] = useState<number | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [inputMessage, setInputMessage] = useState("");
  const [streamingText, setStreamingText] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const [selectedImage, setSelectedImage] = useState<{ base64: string; mimeType: string; preview: string } | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { signOut } = useClerk();
  const { user } = useUser();

  const isSending = isThinking || isStreaming;

  const { data: conversations, isLoading: loadingConversations } = useListConversations();
  const createConversation = useCreateConversation();
  const deleteConversation = useDeleteConversation();

  const { data: activeConversation } = useGetConversation(
    activeConversationId as number,
    { query: { enabled: !!activeConversationId, queryKey: getGetConversationQueryKey(activeConversationId as number) } }
  );

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [activeConversation?.messages, streamingText, isThinking, isStreaming]);

  const handleNewChat = () => {
    setActiveConversationId(null);
    setInputMessage("");
    setStreamingText("");
    setSelectedImage(null);
    if (window.innerWidth < 768) setSidebarOpen(false);
  };

  const handleSelectConversation = (id: number) => {
    setActiveConversationId(id);
    if (window.innerWidth < 768) setSidebarOpen(false);
  };

  const handleDeleteConversation = async (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    try {
      await deleteConversation.mutateAsync({ id });
      queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
      if (activeConversationId === id) setActiveConversationId(null);
    } catch {
      toast({ title: "Erro ao deletar conversa", variant: "destructive" });
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast({ title: "Apenas imagens são suportadas", variant: "destructive" });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(",")[1];
      setSelectedImage({ base64, mimeType: file.type, preview: result });
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const sendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputMessage.trim() && !selectedImage) return;
    if (isSending) return;

    let targetConvId = activeConversationId;
    const msgContent = inputMessage.trim();
    const imgToSend = selectedImage;
    setInputMessage("");
    setSelectedImage(null);
    setIsThinking(true);
    setIsStreaming(false);
    setStreamingText("");

    try {
      if (!targetConvId) {
        const title = msgContent.slice(0, 40) || "Imagem";
        const newConv = await createConversation.mutateAsync({
          data: { title: title + (msgContent.length > 40 ? "..." : "") }
        });
        targetConvId = newConv.id;
        setActiveConversationId(targetConvId);
        queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
      }

      const displayContent = imgToSend
        ? (msgContent ? `[Imagem] ${msgContent}` : "[Imagem]")
        : msgContent;

      queryClient.setQueryData(getGetConversationQueryKey(targetConvId), (old: any) => {
        if (!old) return old;
        return {
          ...old,
          messages: [
            ...(old.messages || []),
            {
              id: Date.now(),
              conversationId: targetConvId,
              role: "user",
              content: displayContent,
              imagePreview: imgToSend?.preview,
              createdAt: new Date().toISOString()
            }
          ]
        };
      });

      const body: Record<string, string> = { content: msgContent };
      if (imgToSend) {
        body.imageBase64 = imgToSend.base64;
        body.imageMimeType = imgToSend.mimeType;
      }

      const response = await fetch(`/api/chat/conversations/${targetConvId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!response.ok) throw new Error("Failed to send");

      const reader = response.body!.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let started = false;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            const dataStr = line.slice(6).trim();
            if (!dataStr) continue;
            try {
              const data = JSON.parse(dataStr);
              if (data.content) {
                if (!started) {
                  started = true;
                  setIsThinking(false);
                  setIsStreaming(true);
                }
                setStreamingText(prev => prev + data.content);
              }
            } catch { /* ignore */ }
          }
        }
      }

      queryClient.invalidateQueries({ queryKey: getGetConversationQueryKey(targetConvId) });
    } catch {
      toast({ title: "Erro ao enviar mensagem", variant: "destructive" });
    } finally {
      setIsThinking(false);
      setIsStreaming(false);
      setStreamingText("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const allMessages = activeConversation?.messages ?? [];
  const showWelcome = !activeConversationId && !isSending;

  return (
    <div className="flex h-[100dvh] w-full bg-background text-foreground overflow-hidden font-sans">

      {/* Sidebar */}
      <div className={cn(
        "absolute md:relative z-20 h-full w-[280px] md:w-[300px] shrink-0 border-r border-border bg-sidebar transition-transform duration-300 ease-in-out flex flex-col",
        sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
      )}>
        <div className="p-4 flex items-center justify-between border-b border-border/50">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-md bg-primary/20 flex items-center justify-center border border-primary/50" style={{ boxShadow: "0 0 10px rgba(168,85,247,0.2)" }}>
              <Zap className="h-4 w-4 text-primary" />
            </div>
            <span className="font-mono font-bold tracking-wider text-primary uppercase" style={{ textShadow: "0 0 10px rgba(168,85,247,0.4)" }}>KRYNO IA</span>
          </div>
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setSidebarOpen(false)}>
            <ChevronLeft className="h-5 w-5 text-muted-foreground" />
          </Button>
        </div>

        <div className="p-3">
          <Button
            onClick={handleNewChat}
            data-testid="button-new-chat"
            className="w-full justify-start gap-2 bg-secondary hover:bg-primary/20 hover:text-primary transition-colors border border-border hover:border-primary/50 text-foreground"
          >
            <Plus className="h-4 w-4" />
            Nova Sessão
          </Button>
        </div>

        <ScrollArea className="flex-1 px-3">
          <div className="space-y-1 pb-4">
            <h4 className="text-xs font-mono font-medium text-muted-foreground mb-2 px-2 pt-2">HISTÓRICO</h4>
            {loadingConversations ? (
              <div className="flex justify-center py-4">
                <div className="h-4 w-4 rounded-full border-2 border-primary border-t-transparent animate-spin" />
              </div>
            ) : conversations?.length === 0 ? (
              <div className="text-sm text-muted-foreground px-2 py-2">Nenhuma sessão ativa.</div>
            ) : (
              conversations?.map((conv) => (
                <div
                  key={conv.id}
                  data-testid={`conv-item-${conv.id}`}
                  onClick={() => handleSelectConversation(conv.id)}
                  className={cn(
                    "group flex items-center justify-between rounded-md px-3 py-2 text-sm cursor-pointer transition-all",
                    activeConversationId === conv.id
                      ? "bg-primary/10 text-primary border border-primary/30"
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground border border-transparent"
                  )}
                >
                  <div className="flex items-center gap-2 overflow-hidden">
                    <MessageSquare className="h-4 w-4 shrink-0" />
                    <span className="truncate">{conv.title || "Sessão sem título"}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 opacity-0 group-hover:opacity-100 hover:text-destructive hover:bg-destructive/20"
                    onClick={(e) => handleDeleteConversation(e, conv.id)}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              ))
            )}
          </div>
        </ScrollArea>

        <div className="p-3 border-t border-border/50">
          {user && (
            <div className="flex items-center justify-between px-1 mb-2">
              <span className="text-xs text-muted-foreground truncate">{user.primaryEmailAddress?.emailAddress}</span>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 hover:text-destructive"
                onClick={() => signOut({ redirectUrl: `${basePath}/sign-in` })}
                data-testid="button-sign-out"
              >
                <LogOut className="h-3.5 w-3.5" />
              </Button>
            </div>
          )}
          <p className="text-[10px] font-mono text-muted-foreground text-center">SISTEMA_PRONTO_</p>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col relative min-w-0">

        {/* Header */}
        <header className="h-14 border-b border-border bg-background/80 backdrop-blur-sm flex items-center px-4 z-10 gap-3">
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setSidebarOpen(true)}>
            <Menu className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-md bg-primary/20 flex items-center justify-center border border-primary/40">
              <Zap className="h-3.5 w-3.5 text-primary" />
            </div>
            <span className="font-mono font-bold text-primary tracking-wider uppercase" style={{ textShadow: "0 0 10px rgba(168,85,247,0.4)" }}>
              Kryno IA
            </span>
          </div>
        </header>

        {/* Chat Content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6" ref={scrollRef}>
          {showWelcome ? (
            <div className="h-full flex flex-col items-center justify-center text-center px-4">
              <div className="h-20 w-20 rounded-2xl bg-primary/10 flex items-center justify-center border border-primary/30 mb-6" style={{ boxShadow: "0 0 30px rgba(139,92,246,0.15)" }}>
                <Zap className="h-10 w-10 text-primary" />
              </div>
              <h2 className="text-2xl font-bold mb-2 font-mono tracking-wider text-primary" style={{ textShadow: "0 0 20px rgba(168,85,247,0.5)" }}>KRYNO IA</h2>
              <p className="text-muted-foreground max-w-md font-mono text-sm">
                Unidade cognitiva ativada. Como posso te ajudar?
              </p>
            </div>
          ) : (
            <div className="max-w-3xl mx-auto space-y-5 pb-36">

              {/* Welcome message */}
              {(activeConversationId || isSending) && (
                <div className="flex w-full justify-start">
                  <div className="max-w-[85%] rounded-xl px-4 py-3 bg-primary/5 border border-primary/20">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="h-5 w-5 rounded-md bg-primary/20 flex items-center justify-center border border-primary/40">
                        <Zap className="h-3 w-3 text-primary" />
                      </div>
                      <span className="font-mono text-[10px] text-primary tracking-widest uppercase">Kryno</span>
                    </div>
                    <p className="text-sm text-foreground/90">{WELCOME_MESSAGE}</p>
                  </div>
                </div>
              )}

              {/* Messages */}
              {allMessages.map((msg: any, idx: number) => (
                <div key={msg.id || idx} className={cn("flex w-full", msg.role === "user" ? "justify-end" : "justify-start")}>
                  <div className={cn(
                    "max-w-[85%] rounded-xl px-4 py-3",
                    msg.role === "user"
                      ? "bg-secondary text-foreground border border-border"
                      : "bg-primary/5 border border-primary/20 text-foreground"
                  )}>
                    {msg.role === "assistant" && (
                      <div className="flex items-center gap-2 mb-2">
                        <div className="h-5 w-5 rounded-md bg-primary/20 flex items-center justify-center border border-primary/40">
                          <Zap className="h-3 w-3 text-primary" />
                        </div>
                        <span className="font-mono text-[10px] text-primary tracking-widest uppercase">Kryno</span>
                      </div>
                    )}
                    {msg.imagePreview && (
                      <img
                        src={msg.imagePreview}
                        alt="Imagem enviada"
                        className="max-w-full rounded-lg mb-2 max-h-60 object-contain"
                      />
                    )}
                    <div className="prose prose-invert prose-p:leading-relaxed prose-pre:bg-black/50 prose-pre:border prose-pre:border-border text-sm max-w-none break-words">
                      <ReactMarkdown>{msg.content.replace(/^\[Imagem(?: enviada)?\]\s?/, "")}</ReactMarkdown>
                    </div>
                  </div>
                </div>
              ))}

              {isThinking && <ThinkingIndicator />}

              {isStreaming && streamingText && (
                <div className="flex w-full justify-start">
                  <div className="max-w-[85%] rounded-xl px-4 py-3 bg-primary/5 border border-primary/20">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="h-5 w-5 rounded-md bg-primary/20 flex items-center justify-center border border-primary/40">
                        <Zap className="h-3 w-3 text-primary" />
                      </div>
                      <span className="font-mono text-[10px] text-primary tracking-widest uppercase">Kryno</span>
                      <div className="h-3 w-3 rounded-full border-2 border-primary border-t-transparent animate-spin" />
                    </div>
                    <div className="prose prose-invert prose-p:leading-relaxed prose-pre:bg-black/50 prose-pre:border prose-pre:border-border text-sm max-w-none break-words">
                      <ReactMarkdown>{streamingText}</ReactMarkdown>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-background via-background/95 to-transparent pt-8">
          <div className="max-w-3xl mx-auto">

            {/* Image preview */}
            {selectedImage && (
              <div className="mb-2 relative inline-block">
                <img
                  src={selectedImage.preview}
                  alt="Preview"
                  className="h-20 w-20 rounded-lg object-cover border border-primary/40"
                />
                <button
                  type="button"
                  onClick={() => setSelectedImage(null)}
                  className="absolute -top-2 -right-2 h-5 w-5 rounded-full bg-destructive flex items-center justify-center"
                >
                  <X className="h-3 w-3 text-white" />
                </button>
              </div>
            )}

            <form onSubmit={sendMessage} className="relative flex items-end gap-2">
              <div className="flex-1 relative flex items-end shadow-lg shadow-black/50">
                <textarea
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Mensagem para Kryno IA..."
                  data-testid="input-message"
                  className="w-full min-h-[52px] max-h-[200px] bg-secondary border border-border rounded-xl pl-4 pr-12 py-3.5 text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary resize-none scrollbar-hidden transition-all"
                  rows={1}
                  disabled={isSending}
                />
                {/* Image upload button inside input */}
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isSending}
                  className="absolute right-3 bottom-3 text-muted-foreground hover:text-primary transition-colors disabled:opacity-40"
                  data-testid="button-image-upload"
                  title="Enviar imagem"
                >
                  <ImagePlus className="h-5 w-5" />
                </button>
              </div>

              <Button
                type="submit"
                size="icon"
                data-testid="button-send"
                disabled={(!inputMessage.trim() && !selectedImage) || isSending}
                className="h-[52px] w-[52px] rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground transition-all disabled:opacity-50 shrink-0"
                style={{ boxShadow: (inputMessage.trim() || selectedImage) && !isSending ? "0 0 20px rgba(139,92,246,0.5)" : "none" }}
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleImageSelect}
            />

            <p className="text-center mt-2 text-[11px] text-muted-foreground">
              O Kryno é uma IA e pode cometer erros.
            </p>
          </div>
        </div>
      </div>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-10 md:hidden backdrop-blur-sm"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
